The getGnuGoData.py program opens an instance of gnuGo in gtp mode, using the subprocess module in python, 
and communicates with it over a socket. After the instance is open, the program sends random
moves for the gnuGo instance to play. Then, gnuGo sends the board state as a string back to
the program along with the next move that it generated. It then converts that board state
to a list, appending it to the 2D data list, and inserts a 1 into the right position in a 
list of zeros, appending that to the 2D list of labels. The program will save the data and
labels to files along the way.



Methods:
	kill
		@param process: a subprocess process
		- kills the given process
	convert
		@param str: a gnuGo board string
		- converts the board string into a list of numbers, with 1 representing white, 2 representing black, and 0 representing no stone
	addLabel
		@param position: a position string on the board, returned by gnuGo. ex. 'A1'
		- inserts a 1 into a zero list of size 25 as position, then appends that the the labels
	main
		- starts the gnuGo session and plays a game with the engine. When both sides pass or someone resigns, the session ends and this method returns the data and labels list


global variables:
	data_dir
		- the directory the data is saved to
	alphabet
		- A list of tuples of the numbers and letters that make up the board positions, representing all of the legal moves on an empty board.
	labels
		- a 2D list of best moves we use to train our model
	data
		- a 2D list of board states that correspond to the labels, we also use this to train our model
	random_move
		- a random tuple is picked from the alphabet which is then relayed to gnuGo for it's next move (black)