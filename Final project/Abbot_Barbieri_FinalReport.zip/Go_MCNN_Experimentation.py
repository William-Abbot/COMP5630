from init__ import GoTextNetwork, FailedCommand
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from io import StringIO

import matplotlib.pyplot as plt

from multiprocessing import Pool, Process

import numpy as np
import pandas as pd
import random
import sgf
import subprocess

def import_data(file_name, index_col=0):
	with open(file_name) as f:
		data = f.read()
		parsed_data = pd.read_csv(StringIO(data), index_col=index_col)
	
	num_rows = len(parsed_data)
	num_data_pts = int((num_rows) / 2)
	
	X = parsed_data[0:num_data_pts].to_numpy()
	y = parsed_data[num_data_pts:num_rows].to_numpy()
		
	return X, y

# Creates, trains, and returns a trained Multi-layer NN on the dataset for 7x7 games
# Network will have 25 inputs and 49 outputs
#def create_network(X, y):
#	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.3)
	
#	nn = MLPClassifier(activation='relu', learning_rate='constant', learning_rate_init=0.001)
#	nn.fit(X_train, y_train)
#	score = nn.score(X_test, y_test)
	
#	print("Test Accuracy: " + str(score))
#	return nn

# Trains a Multi-layer NN on the dataset and returns the scores
def create_network(X_train, y_train, X_test, y_test, nn):
    nn.fit(X_train, y_train)
    
    score = nn.score(X_train, y_train)
    #print("Training Accuracy: " + str(score))
    
    score_test = nn.score(X_test, y_test)
    #print("Test Accuracy: " + str(score))
    return score, score_test

# Create an instance of gnugo to interface with it
def create_network_go(level, size, port):
    # Start an instance of gnugo.
    cmd = "./gnugo --mode gtp --gtp-listen 127.0.0.1:" + str(port) + " --boardsize " + str(size) + " --level " + str(level)
    p = subprocess.Popen(cmd.split())

    go = GoTextNetwork('localhost', port)
    return p, go

# Kill the connection to gnugo
def kill_connection(proc):
    proc.kill()

def is_game_over(go_cpu, num_consec_passes):
    if (num_consec_passes >= 2):
        return True, go_cpu.final_score().strip()

    return False, ''

def convert(str):
    newline_count = 0
    arr = list()
    line5 = [0]*5
    line4 = [0]*5
    line3 = [0]*5
    line2 = [0]*5
    line1 = [0]*5
    position = 0
    offset = 0
    for s in range(len(str)):
        if newline_count == 2:
            line5[0] = str[s+3]
            line5[1] = str[s+5]
            line5[2] = str[s+7]
            line5[3] = str[s+9]
            line5[4] = str[s+11]
            newline_count += 1
    
        if newline_count == 4:
            s2 = str[s+5]
            s4 = str[s+9]
            if s2 == '+':
                s2 = '.'
            else:
                s2 = str[s+5]
            if s4 == '+':
                s4 = '.'
            else:
                s4 = str[s+9]
            line4[0] = str[s+3]
            line4[1] = s2
            line4[2] = str[s+7]
            line4[3] = s4
            line4[4] = str[s+11]
            newline_count += 1
        
        if newline_count == 6:
            s3 = str[s+7]
            if s3 == '+':
                s3 = '.'
            else:
                s3 = str[s+7]
            line3[0] = str[s+3]
            line3[1] = str[s+5]
            line3[2] = s3
            line3[3] = str[s+9]
            line3[4] = str[s+11]
            newline_count += 1
            
        if newline_count == 8:
            s2 = str[s+5]
            s4 = str[s+9]
            if s2 == '+':
                s2 = '.'
            else:
                s2 = str[s+5]
            if s4 == '+':
                s4 = '.'
            else:
                s4 = str[s+9]
            line2[0] = str[s+3]
            line2[1] = s2
            line2[2] = str[s+7]
            line2[3] = s4
            line2[4] = str[s+11]
            newline_count += 1
            
        if newline_count == 10:
            line1[0] = str[s+3]
            line1[1] = str[s+5]
            line1[2] = str[s+7]
            line1[3] = str[s+9]
            line1[4] = str[s+11]
            newline_count += 1
    
        elif s < len(str)-1:
            if str[s] == '\n':
                newline_count += 1

    arr = line5+line4+line3+line2+line1
    for i in range(len(arr)):
        if arr[i] == 'X':
            arr[i] = 2
        if arr[i] == 'O':
            arr[i] = 1
        if arr[i] == '.':
            arr[i] = 0
    return arr

# Returns 1 if the model won and - if the model lost
def play_single_game(model, level, board_dim, kernel, difficulty, port=5000):
    is_over = False
    result = ''
    num_consec_passes = 0

    # Instantiate the go player
    proc, go_cpu = create_network_go(level, board_dim, port)
    
    while (not is_over):
        play_rand_move = False
        
        if difficulty == 'suboptimal' and random.random() > 0.7:
            play_rand_move = True
        
	    # Play Black
        if difficulty == 'random' or play_rand_move:
            try:
                vertex = random.choice([chr(ord('A') + i) for i in range(board_dim)])
                vertex += str(random.choice([(j + 1) for j in range(board_dim)]))
                go_cpu.play('white', vertex)
            
            except FailedCommand:
                go_cpu.play('black', 'pass')
        else:
            go_cpu.genmove("black")
            
        last_move = go_cpu.last_move()

        if (not (last_move.find('PASS') == -1)):
            num_consec_passes += 1
        else:
            num_consec_passes = 0
        
	    # Determine if game is over
        is_over, result = is_game_over(go_cpu, num_consec_passes)
        if (is_over):
            break
        
	    # Get/format board for input into nn
        board = np.array(convert(go_cpu.showboard()))

        # Convolve the board if playing on the 7x7 board
        if board_dim == 7:
            #!!!!!!!!!! Board is 1X49, but needs to be 7x7!!!!!!!!!!!!!!!
            reduced_board = convolve_board(board, kernel)

	    # Feed board into nn
        output = model.predict(board.reshape(1,-1))

        # Convert output to board square and feed back into gnugo
        index = -1

        for i, out in enumerate(output[0]):
            if out == 1:
                index = i
                break

        try:
            if index == -1:
                #vertex = random.choice([chr(ord('A') + i) for i in range(board_dim)])
                #vertex += str(random.choice([(j + 1) for j in range(board_dim)]))
                #go_cpu.play('white', vertex)
                go_cpu.play('white', 'pass')
                num_consec_passes += 1
            else:
                col = (int(index / board_dim) - board_dim) * (-1)
                row = chr(ord('A') + (index % board_dim))
                vertex = row + str(col)
                go_cpu.play('white', vertex)
                num_consec_passes = 0

        except FailedCommand:
            go_cpu.play('white', 'pass')
            num_consec_passes += 1

	    # Determine if game is over
        is_over, result = is_game_over(go_cpu, num_consec_passes)
    
    # Kill the go player
    kill_connection(proc)
    
    if (result[0] == "0"):
        return 0
    elif (result[0] == "B"):
        return -1
    
    return 1

# Play against an optimal opponent
def test_vs_opponent(difficulty, num_games, model, port=5000):
    level = 10

    if (difficulty == 'random'):
        level = 0
        #print("Playing random player")
    elif (difficulty == 'suboptimal'):
        level = 5
        #print("Playing suboptimal player")
    elif (difficulty == 'optimal'):
        level = 10
        #print("Playing optimal player")
    else:
        print("Incorrect Difficulty option")
        return
    
    # Play the games and analyze how many were won and lost
    num_won = 0
    num_draw = 0
    
    # with Pool() as pool:
        # for result in pool.starmap(play_single_game, [(model, level, 5, [], port + i) for i in range(num_games)]):
            # if result == 1:
                # num_won += 1
            # elif result == 0:
                # num_draw += 1
                
    for i in range(num_games):
        result = play_single_game(model, level, 5, [], difficulty, port)
        
        if result == 1:
            num_won += 1
        elif result == 0:
            num_draw += 1

    return num_won, num_draw
    # Display win percentage
    #print("Record: " + str(int(num_won)) + "-" + str(int(num_games - num_won - num_draw)) + "-" + str(num_draw))
    #print("Average: " + str(num_won / num_games))

# Convolve a board with a kernel
def convolve_board(board, kernel):
    m, n = kernel.shape
    if (m == n):
        y, x = board.shape
        y = y - m + 1
        x = x - m + 1
        new_board = np.zeros((y,x))
        for i in range(y):
            for j in range(x):
                new_board[i][j] = np.sum(board[i:i+m, j:j+m]*kernel)

    return new_board

# Play on a 7x7 board
def test_on_7x7(num_games, model, kernel):
    print("Playing suboptimal player on 7x7 board")
    level = 5

    # Play the games and analyze how many were won and lost
    num_won = 0.0
    num_draw = 0
    
    for i in range(num_games):
        did_win = play_single_game(model, level, 7, kernel)
        
        if did_win == 1:
            num_won += 1
        elif did_win == 0:
            num_draw += 1
    
    # Display win percentage
    print("Record: " + str(int(num_won)) + "-" + str(int(num_games - num_won - num_draw)) + "-" + str(num_draw))
    print("Average: " + str(num_won / num_games))

def import_all_data():
    X, y = import_data("Datasets/full_data_rand.csv", None)
    X_2, y_2 = import_data("Datasets/data_rand.csv")
    X_3, y_3 = import_data("Datasets/data_some_rand.csv")
    X_4, y_4 = import_data("Datasets/data_ideal.csv")
    X_5, y_5 = import_data("Datasets/data_rand_new.csv")

    X = np.append(X, X_2, axis=0)
    X = np.append(X, X_3, axis=0)
    X = np.append(X, X_4, axis=0)
    X = np.append(X, X_5, axis=0)
    
    y = np.append(y, y_2, axis=0)
    y = np.append(y, y_3, axis=0)
    y = np.append(y, y_4, axis=0)
    y = np.append(y, y_5, axis=0)
    
    return X, y

def test_optimized_model(X_train, y_train, X_test, y_test, num_iter):
    results = np.zeros((num_iter, 8))
    nn = None

    for i in range(num_iter):
        nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.01,\
            verbose=False, max_iter=10000, hidden_layer_sizes=(50, 700), solver='adam')
        results[i,0:2] = create_network(X_train, y_train, X_test, y_test, nn)
        
        results[i,2:4] = test_vs_opponent('random', 30, nn)
        
        #print(str(num_win) + "-" + str(30-num_win-num_draw) + "-" + str(num_draw))
        
        results[i,4:6] = test_vs_opponent('suboptimal', 30, nn)
        
        #print(str(num_win) + "-" + str(30-num_win-num_draw) + "-" + str(num_draw))
        
        results[i,6:8] = test_vs_opponent('optimal', 30, nn)
        
        #print(str(num_win) + "-" + str(30-num_win-num_draw) + "-" + str(num_draw))
        print("Finished iter: " + str(i))
        
    save_confusion(nn, X_train, y_train, "TrainDataTest.csv")
    save_confusion(nn, X_test, y_test, "TestDataTest.csv")
    
    return results

def test_learning_rate(X_train, y_train, X_test, y_test, rate, port, num_iter):
    # Row corresponds to:
    #   train accuracy, test accuracy, num wins, num ties
    results = np.zeros((num_iter, 2))

    for i in range(num_iter):
        nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=rate,\
            max_iter=10000, hidden_layer_sizes=(50, 300), solver='adam')
        
        results[i,0:2] = create_network(X_train, y_train, X_test, y_test, nn)
        #results[i,2:4] = test_vs_opponent('random', num_iter, nn, port)
        
        print("Finished iter " + str(i) + " on port " + str(port))
    
    return results
    
def test_num_hidden_layer(X_train, y_train, X_test, y_test, num_layer, port, num_iter):
    # Row corresponds to:
    #   train accuracy, test accuracy, num wins, num ties
    results = np.zeros((num_iter, 2))

    for i in range(num_iter):
        nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.001,\
            max_iter=10000, hidden_layer_sizes=(num_layer, 300), solver='adam')
        
        results[i,0:2] = create_network(X_train, y_train, X_test, y_test, nn)
        #results[i,2:4] = test_vs_opponent('random', num_iter, nn, port)
        
        print("Finished iter " + str(i) + " on port " + str(port))
    
    return results
    
def test_hidden_layer_size(X_train, y_train, X_test, y_test, layer_size, port, num_iter):
    # Row corresponds to:
    #   train accuracy, test accuracy, num wins, num ties
    results = np.zeros((num_iter, 2))

    for i in range(num_iter):
        nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.001,\
            max_iter=10000, hidden_layer_sizes=(50, layer_size), solver='adam')
        
        results[i,0:2] = create_network(X_train, y_train, X_test, y_test, nn)
        #results[i,2:4] = test_vs_opponent('random', num_iter, nn, port)
        
        print("Finished iter " + str(i) + " on port " + str(port))
    
    return results
    
def test_activation(X_train, y_train, X_test, y_test, activation, port, num_iter):
    # Row corresponds to:
    #   train accuracy, test accuracy, num wins, num ties
    results = np.zeros((num_iter, 2))

    for i in range(num_iter):
        nn = MLPClassifier(activation=activation, learning_rate='adaptive', learning_rate_init=0.001,\
            max_iter=10000, hidden_layer_sizes=(50, 300), solver='adam')
        
        results[i,0:2] = create_network(X_train, y_train, X_test, y_test, nn)
        #results[i,2:4] = test_vs_opponent('random', num_iter, nn, port)
        
        print("Finished " + activation + " on port " + str(port))
    
    return results

def test_results_to_csv(results, file_name, indep_var, num_iter):
    names = ['x', 'y', 'z']
    index = pd.MultiIndex.from_product([range(s)for s in np.shape(results)], names=names)
    df = pd.DataFrame({'A': results.flatten()}, index=index)['A']
    
    df = df.unstack(level='z')#.swaplevel().sort_index()
    df.columns = ['Train Avg','Test Avg','Num Win','Num Tie']
    df.index.names = [indep_var, 'Iteration']
    #df.set_levels(test_labels, range(num_iter))
    
    df.to_csv(file_name)

def save_confusion(model, X, y, file_name):
    c = confusion_matrix(np.argmax(y, axis=1), np.argmax(model.predict(X), axis=1))
    df = pd.DataFrame(c)
    df.to_csv(file_name)

def main():
    # Create the MLNN 
    
    # 88% train 58% test
    #nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.01,\
    #    verbose=True, max_iter=10000, hidden_layer_sizes=(50, 300), solver='adam')
    
    #nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.05,\
    #    verbose=True, max_iter=10000, hidden_layer_sizes=(550, 300), solver='sgd')
    
    #nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.05,\
    #    verbose=True, max_iter=10000, hidden_layer_sizes=(650, 300), solver='sgd')
    
    # nn = MLPClassifier(activation='tanh', learning_rate='adaptive', learning_rate_init=0.005,\
    #     verbose=True, max_iter=10000, hidden_layer_sizes=(1000, 500), solver='adam')

    #trained_net = create_network(X, y, nn)

    num_iter = 30

    X, y = import_all_data()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.3)
    
    results = test_optimized_model(X_train, y_train, X_test, y_test, num_iter)
    pd.DataFrame(results).to_csv("Optimal_Test.csv")
    #test_results_to_csv(np.array(results), "LearningRateTestResults.csv", 'Learning Rate', num_iter)
    
    # test = plot_confusion_matrix(nn, X_test, np.argmax(y_test, axis=1))
    # plt.show()
    #print(test.confustion_matrix)
    
    # Test learning rates
    #for i in range(0.001, 0.1, 0.01):
    # learning_rates = [0.0001, 0.001, 0.01, 0.05, 0.1, 0.5, 1]#np.arange(0.001, 0.1, 0.01)
    # ports = [300 + (i * 200) for i in range(len(learning_rates))]
    
    # with Pool() as pool:        
        # averages = pool.starmap(test_learning_rate, [(X_train, y_train, X_test, y_test, \
            # learning_rates[i], ports[i], num_iter) for i in range(len(learning_rates))])
        
        # test_results_to_csv(np.array(averages), "LearningRateTestResults.csv", 'Learning Rate', num_iter)
    
    # print()
    # #print(averages)
    # print("Done with learning rate tests")
    # print()
    
    # layer_sizes = [50, 100, 200, 400, 600]#np.arange(0.001, 0.1, 0.01)
    # ports = [300 + (i * 200) for i in range(len(layer_sizes))]
    
    # with Pool() as pool:        
        # averages = pool.starmap(test_hidden_layer_size, [(X_train, y_train, X_test, y_test, \
            # layer_sizes[i], ports[i], num_iter) for i in range(len(layer_sizes))])
        
        # test_results_to_csv(np.array(averages), "LayerSizeTestResults.csv", 'Layer Size', num_iter)
    
    # print()
    # print("Done with layer size tests")
    # print()
    
    # num_layers = [5, 10, 50, 100, 200, 500]#np.arange(0.001, 0.1, 0.01)
    # ports = [300 + (i * 200) for i in range(len(num_layers))]
    
    # with Pool() as pool:        
        # averages = pool.starmap(test_num_hidden_layer, [(X_train, y_train, X_test, y_test, \
            # num_layers[i], ports[i], num_iter) for i in range(len(num_layers))])
        
        # test_results_to_csv(np.array(averages), "NumLayersTestResults.csv", 'Num Layers', num_iter)
    
    # print()
    # print("Done with num layer tests")
    # print() 
    
    # activations = ['tanh','logistic','relu','identity']#np.arange(0.001, 0.1, 0.01)
    # ports = [300 + (i * 200) for i in range(len(activations))]
    
    # with Pool() as pool:        
        # averages = pool.starmap(test_activation, [(X_train, y_train, X_test, y_test, \
            # activations[i], ports[i], num_iter) for i in range(len(activations))])
        
        # test_results_to_csv(np.array(averages), "ActivationTestResults.csv", 'Activation', num_iter)
    
    # print()
    # print("Done with activation tests")
    # print() 

    # Test on 5x5 boards
    #num_games = 60
    #test_vs_opponent('optimal', num_games, trained_net)
    #test_vs_opponent('suboptimal', num_games, trained_net)
    #test_vs_opponent('random', num_games, trained_net)

    ## Create MLNN model for the 7x7 board
    #trained_7x7_net = create_7x7_network(X, y)

    ## Test on 7x7 board
    #test_on_7x7(num_games, trained_7x7_net)

if __name__ == '__main__':
    main()
