This is the README for Go_MCNN_Experimentation.py file. This is the python file in which we 
conducted all of our experiments.

Methods:
	import_data
		@param file_name: name of the file to import data from
		@param index_col: column that contains the row indices (default=0)
		- Import the data set from the file specified by file_name.
		- Returns X as the data points and y as the corresponding labels.
		
	create_network
		@param X_train: training split of the input set
		@param y_train: training split of the label set
		@param X_test: testing split of the input set
		@param y_test: testing split of the label set
		@param nn: model to train and score
		- Fit the network to the dataset specified by X_train and y_train.
		- Returns the accuracy on both the training and testing data sets
		
	create_network_go
		@param level: depth in look ahead tree to which the GNUGo player will search
		@param size: size of the board (i.e. 5 => 5x5 board)
		@param port: port on which to create the new GNUGo instance
		- Opens a new instance of GNUGo over the specified port. The game will have the specified board size and level.
		- Returns the newly opened instance.
		
	kill_connection
		@param proc: GNUGo instance to kill
		- Kills the instance of network go specified by proc.
		
	is_game_over
		@param go_cpu: instance of GNUGo to evaluate
		@param num_consec_passes: number of consecutive times that players have passed (i.e. black passes, white passes => 2 consec. passes)
		- Checks to see if the game is over by checking the number of consecutive passes.
		- Returns true and the final score of the game if two consecutive passes have been made
		- Returns false if the game is not over yet
		
	convert
		@param str: board string to convert
		- Convert the string representation of the board (obtained by network_go_instance.showboard()) str into an array that can be read into the multiclass model.
		- Returns the array made from the board string.
		
	play_single_game
		@param model: neural network model to pit against GNUGo
		@param level: depth in look ahead tree to which the GNUGo player will search
		@param board_dim: size of the board (i.e. 5 => 5x5 board)
		@param kernel: does not do anything, as we were unable to implement the 7x7 player
		@param difficulty: one of 'random', 'suboptimal', or 'optimal'. Used to set difficulty of GNUGo
		@param port: port on which to create the new GNUGo instance
		- Plays a game betwen model and a new instance of GNUGo on port "port." The new instance of GNUGo will have the specified
			level and board size. Kernel does not do anything, as we were unable to implement the 7x7 player. Difficulty can be
			any of 'random', 'suboptimal', or 'optimal'.
		- Returns 1 if model won, -1 if GNUGo won, and 0 if it was a draw

	test_vs_opponent
		@param difficulty: one of 'random', 'suboptimal', or 'optimal'. Used to set difficulty of GNUGo
		@param num_games: number of games to play before returning the results
		@param model: neural network model to pit against GNUGo
		@param port: port on which to create the new GNUGo instance
		- Runs "num_games" between "model" and different instances of GNUGo and records the results
		- Returns the number of games that "model" won and the number of games that were a draw.
		
	convolve_board
		@param board: current 7x7 board state
		@param kernel: kernel with which to convolve the board
		- Convolves board array "board" with "kernel". Does not function because we did not implement the 7x7 player.
		- Returns the convolved board
		
	test_on_7x7
		@param num_games: number of games to play before returning the results
		@param model: neural network model to pit against GNUGo
		@param kernel: kernel with which to convolve the board
		- Same as test_vs_opponent, but on a 7x7 board. This was not implemented because we did not implement the 7x7 player
		
	import_all_data()
		- Imports all data sets specified in the method
		- Returns the aggregated data set and corresponding labels
		
	test_optimized_model
		@param X_train: training split of the input set
		@param y_train: training split of the label set
		@param X_test: testing split of the input set
		@param y_test: testing split of the label set
		@param num_iter: number of games to play before returning the results
		- Creates the optimized model and tests it on the specified training and testing sets. Repeats "num_iter" times.
			Also saves out the trained model's confusion matrices for the training and testing data.
		- Returns an array containing the average testing accuracy, average training accuracy, number of games won and drawn against
			a random opponent, number of games won and drawn against a suboptimal opponent, and number of games won and drawn against
			an optimal opponent
			
	test_learning_rate
		@param X_train: training split of the input set
		@param y_train: training split of the label set
		@param X_test: testing split of the input set
		@param y_test: testing split of the label set
		@param rate: value for learning rate to test
		@param port: port on which to create the new GNUGo instance
		@param num_iter: number of games to play before returning the results
		- Conducts the learning rate experiment for a single learning rate. Conducts "num_iter" trials.
		- Returns an array containing the average testing accuracy and average training accuracy
		
	test num_hidden_layer
		@param X_train: training split of the input set
		@param y_train: training split of the label set
		@param X_test: testing split of the input set
		@param y_test: testing split of the label set
		@param rate: value for number of hidden layers to test
		@param port: port on which to create the new GNUGo instance
		@param num_iter: number of games to play before returning the results
		- Conducts the number of hidden layers experiment for a single number of hidden layers. Conducts "num_iter" trials.
		- Returns an array containing the average testing accuracy and average training accuracy
		
	test_hidden_layer_size
		@param X_train: training split of the input set
		@param y_train: training split of the label set
		@param X_test: testing split of the input set
		@param y_test: testing split of the label set
		@param rate: value for hidden layer size to test
		@param port: port on which to create the new GNUGo instance
		@param num_iter: number of games to play before returning the results
		- Conducts the hidden layer size experiment for a hidden layer size rate. Conducts "num_iter" trials.
		- Returns an array containing the average testing accuracy and average training accuracy
		
	test_activation
		@param X_train: training split of the input set
		@param y_train: training split of the label set
		@param X_test: testing split of the input set
		@param y_test: testing split of the label set
		@param rate: activation function to test
		@param port: port on which to create the new GNUGo instance
		@param num_iter: number of games to play before returning the results
		- Conducts the activation function experiment for a activation function rate. Conducts "num_iter" trials.
		- Returns an array containing the average testing accuracy and average training accuracy
		
	test_results_to_csv
		@param results: array of results returned from "test_" functions
		@param file_name: name to save the csv under
		@param indep_var: name of the independent variable
		@param num_iter: number of trials run for each experiment
		- Saves the results given from any of the 5 experiment functions starting with "test_" as a csv file. You can specify the name of
			the independent variable for the experiment
		
	save_confusion
		@param model: neural network model to calculate the confusion matrix of
		@param X: input set over which to calculate the confusion matrix
		@param y: label set over which to calculate the confusion matrix
		@param file_name: name to save the csv file as
		- Calculates and saves the confusion matrix as a csv file for the specified data set on the given model 
		
	main
		- Serves as a container for the code that will be executed when this python file is run.